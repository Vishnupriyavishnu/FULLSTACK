var express=require('express');
var app=express();
var bodyParser=require('body-parser');

var connection=require('./model/database');

app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(__dirname));

app.get('/register',function(req,res){
  console.log("Hello");
  res.sendFile(__dirname+'/views/register.html');
 
 })
 app.use('/valid',function(req,res)
  {
    var m1=req.body.Email;
    var pass=req.body.Password;
    var passw2=req.body.password2;
    var namevalid=req.body.username;
    var number=req.body.rollnumber;
    console.log("data submitted");
    

    /* res.writeHead(200,{'Content-type':'text/html'});
    res.write("<h3>Registration Success!! </h3>");
    res.end();*/
    connection.query('insert into students_details values(?,?,?,?)',[number,namevalid,m1,pass],(err,results)=>{
      if(err)throw err;
      if(results){
        console.log("Values Inserted");
        res.sendFile(__dirname+'/views/loginst.html');
      }
    })
})  

app.get('/loginst',function(req,res){
 console.log("Hi");
 res.sendFile(__dirname+'/views/loginst.html');

})
 app.post('/validate',function(req,res){
   var m1=req.body.Email;
   var pwd=req.body.password;
   console.log("data submitted");
   connection.query('select email from students_details where email like ?',[m1],(err,results)=>{
     if(err)throw err;
     if(results){
       connection.query('select password from students where email like ? an password like ?',[m1,pwd],(err,results)=>{
         res.send('<h3>Hello everyone</h3>');
       })
     }
   })
  /* res.send(`Email:${m1},Password:${pwd}`);*/
 })

 app.listen(1103,()=>{
   console.log("Server is listening 1103");
 })
 